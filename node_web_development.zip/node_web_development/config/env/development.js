/**
 * Created by Admin on 20/07/16.
 */
module.exports = {
    // Development configuration options
    db: 'mongodb://localhost/mean-book',
    sessionSecret : 'developmentSessionSecret',
    facebook: {
        clientID: '1053639608004424',
        clientSecret: '5e4b79728d200a483f267c5eaeae47b2',
        callbackURL: 'http://localhost:3000/oauth/facebook/callback'
    }
};