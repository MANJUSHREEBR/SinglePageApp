var passport = require('passport'),
    url = require('url'),
    FacebookStrategy = require('passport-facebook').Strategy,
    config = require('../config'),
    users = require('../../app/controllers/users.server.controller');
/**
 * Created by Admin on 20/07/16.
 */
module.exports = function() { passport.use(new FacebookStrategy({
    clientID: config.facebook.clientID, clientSecret: config.facebook.clientSecret, callbackURL: config.facebook.callbackURL,
    passReqToCallback: true,
    profileFields:["email","first_name","last_name"]
},
    function(req, accessToken, refreshToken, profile, done) {
    var providerData = profile._json; providerData.accessToken = accessToken; providerData.refreshToken = refreshToken;
        console.log(profile);
        console.log(profile);
    var providerUserProfile = {

        firstName: profile.name.givenName,
        lastName: profile.name.familyName,
        fullName: profile.name.givenName,
        email: profile.emails[0].value,
        username: profile.username,
        provider: 'facebook',
        providerId: profile.id,
        providerData: providerData
    };
    users.saveOAuthUserProfile(req, providerUserProfile, done); }));
};