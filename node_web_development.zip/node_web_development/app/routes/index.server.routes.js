/**
 * Created by Admin on 19/07/16.
 */
module.exports = function(app){
    var index = require('../controllers/index.server.controller');
    app.get('/',index.render);

};