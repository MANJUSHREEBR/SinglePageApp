/**
 * Created by Admin on 19/07/16.
 */
exports.render = function(req,res){
    if(req.session.lastvisit){
        console.log(req.session.lastVisit);

    }
    req.session.lastVisit = new Date();


};


exports.render = function(req, res) {
    res.render('index', {
        title: 'Hello World',
        user: JSON.stringify(req.user)
    });
};