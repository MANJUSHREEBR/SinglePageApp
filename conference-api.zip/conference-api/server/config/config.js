/**
 * Created by Admin on 13/07/16.
 */
module.exports = {
    // Uncomment to connect with MongoDB on Cloud
    // 'url' : 'mongodb://username:password@kahana.mongohq.
   // com:10073/node-
    //api'
        'url' : 'mongodb://localhost/conferenceDB'
};