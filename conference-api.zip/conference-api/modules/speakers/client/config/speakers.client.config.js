 // Configuring the Articles module and replace the
        // following code:
       angular.module('speakers').run(['Menus',
       function(Menus) {
         // Set top bar menu items
         Menus.addMenuItem('Speakers', 'Speakers', 'speakers',
         'dropdown', '/speakers(/create)?');
         Menus.addSubMenuItem('Speakers', 'speakers', 'ListSpeakers', 'speakers');
         Menus.addSubMenuItem('Speakers', 'speakers', 'NewSpeaker', 'speakers/create');
} ]);

// Configuring the Speakers module
       angular.module('speakers').run(['Menus',
       function(Menus) {
// Set top bar menu items 
        Menus.addMenuItem('topbar', 'Speakers', 'speakers', 'dropdown', '/speakers(/create)?'); 
        Menus.addSubMenuItem('topbar', 'speakers', 'List
          Speakers', 'speakers');