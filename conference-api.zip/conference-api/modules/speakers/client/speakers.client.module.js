(function (app) {
  'use strict';

  app.registerModule('speakers');
})(ApplicationConfiguration);
